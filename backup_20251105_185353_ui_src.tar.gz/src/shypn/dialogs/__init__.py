"""Dialogs subpackage for shypn application."""
