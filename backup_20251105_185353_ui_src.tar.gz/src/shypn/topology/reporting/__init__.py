"""Topology reporting - generate summaries and metadata for Report Panel."""

from .summary_generator import TopologySummaryGenerator

__all__ = ['TopologySummaryGenerator']
