"""Topology result aggregation - transform to per-element properties."""

from .result_aggregator import TopologyResultAggregator

__all__ = ['TopologyResultAggregator']
