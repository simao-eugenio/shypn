# Example helper function (functional style)
def add(a, b):
    return a + b
