"""CrossFetch UI integration components."""

from .enrichment_controller import EnrichmentController

__all__ = ['EnrichmentController']
