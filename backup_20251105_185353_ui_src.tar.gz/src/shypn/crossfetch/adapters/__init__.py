"""Adapters for CrossFetch integration with Shypn."""

from .shypn_adapter import ShypnPathwayAdapter

__all__ = ['ShypnPathwayAdapter']
