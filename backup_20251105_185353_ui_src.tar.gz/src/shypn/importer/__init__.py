"""KEGG pathway import module for shypn."""
