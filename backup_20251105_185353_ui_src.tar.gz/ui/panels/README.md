# Panels

This folder contains dockable and undockable panels, such as sidebars and inspectors, for the application's UI.