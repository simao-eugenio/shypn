# Canvas Interfaces

This folder contains interfaces and components for document models, such as drawing canvases or editors.