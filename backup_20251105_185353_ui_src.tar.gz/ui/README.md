# ui/
This folder contains all user interface resources, such as UI definitions, dialogs, panels, and related assets. It is not for Python code, but for UI files and resources used by the application.